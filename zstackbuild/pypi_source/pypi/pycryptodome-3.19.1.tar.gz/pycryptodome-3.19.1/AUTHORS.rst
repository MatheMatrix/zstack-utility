Simon Arneaud
Nevins Bartolomeo
Thorsten E. Behrens
Tim Berners-Lee
Frédéric Bertolus
Ian Bicking
Joris Bontje
Antoon Bosselaers
Andrea Bottoni
Jean-Paul Calderone
Sergey Chernov
Geremy Condra
Jan Dittberner
Andrew Eland
Philippe Frycia
Peter Gutmann
Hirendra Hindocha
Nikhil Jhingan
Sebastian Kayser
Ryan Kelly
Andrew M. Kuchling
Piers Lauder
Legrandin
M.-A. Lemburg
Wim Lewis
Darsey C. Litzenberger
Richard Mitchell
Mark Moraes
Lim Chee Siang
Bryan Olson
Wallace Owen
Colin Plumb
Robey Pointer
Lorenz Quack
Sebastian Ramacher
Jeethu Rao
James P. Rutledge
Matt Schreiner
Peter Simmons
Janne Snabb
Tom St. Denis
Anders Sundman
Paul Swartz
Fabrizio Tarizzo
Kevin M. Turner
Barry A. Warsaw
Eric Young
Hannes van Niekerk
Stefan Seering
Koki Takahashi
Lauro de Lima
